formats = {
    'separator': '-',
    'TAB': '     ',
    'LINE_LENGTH': 100,
    'BAR_WIDTH': 0.10,
    'INDENT': 10,
    'RISK_FREE_TITLE': "{} US Treasury",
    'BINS': 20
}
